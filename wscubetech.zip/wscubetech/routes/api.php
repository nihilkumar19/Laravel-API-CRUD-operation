<?php

use Illuminate\Http\Request;
use App\Http\Controllers\Api\UserController;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Route;
use League\CommonMark\Inline\Element\Code;
use Psy\Input\CodeArgument;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});




Route::get('/test',function(){
  p("working");
});
Route::post('user/store',[UserController::class,'store']);
Route::get('users/get/{flag}',[UserController::class,'index']);
Route::get('user/{id}',[UserController::class,'show']);
Route::delete('user/delete/{id}',[UserController::class,'destroy']);
Route::put('user/update/{id}',[UserController::class,'update']);

//Route::get('/user',function(){
  //  return "hello Nihil";
//});

//Route::post('/user',function(){
   // return response()->json("Post api hit successfully");
//});

//Route::delete('/user/{id}',function($id){
    //return response("Delete".$id,200);
//});

//Route::put('/user/{id}',function($id){
    //return response("Put".$id,200);
//});



